import { i18n_de } from "./de";
import { i18n_en } from "./en";

const dictionaries = {
  de: i18n_de,
  en: i18n_en,
};

/**
 * 🌍 Mehrsprachige Übersetzungsfunktion
 * Unterstützt mehrere Platzhalter {0}, {1}, {2} usw.
 */
export function t(lang: string, key: string, section: string, params?: any): string {
  try {
    const safeLang = lang === "en" ? "en" : "de";
    const dict = dictionaries[safeLang];
    const sectionData = dict?.[section];
    if (!sectionData) return key;

    let value = sectionData[key];
    if (typeof value === "function") value = value(params);
    if (typeof value !== "string") return key;

    // 🔄 Einzel- oder Mehrfachparameter ersetzen
    if (params !== undefined) {
      if (Array.isArray(params)) {
        params.forEach((p, i) => {
          value = value.replace(new RegExp(`\\{${i}\\}`, "g"), p);
        });
      } else {
        value = value.replace("{0}", params);
      }
    }

    return value;
  } catch (err) {
    console.error("[i18n] Fehler in t():", err);
    return key;
  }
}

/**
 * 🧭 useLang() – erkennt Sprache aus URL oder SSR
 */
export function useLang(defaultLang = "de"): string {
  if (typeof window !== "undefined") {
    return window.location.pathname.includes("/en/") ? "en" : "de";
  }
  return defaultLang;
}

export default { t, useLang };
